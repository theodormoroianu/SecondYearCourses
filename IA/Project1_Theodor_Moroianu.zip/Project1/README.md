# Proiect 1 IA

Problema: Micul vrajitor
Link: [link](http://irinaciocan.ro/inteligenta_artificiala/exemple-teme-a-star.php)
